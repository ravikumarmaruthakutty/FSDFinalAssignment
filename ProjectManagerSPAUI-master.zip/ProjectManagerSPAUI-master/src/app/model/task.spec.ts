import { Task } from './task';

describe('Task', () => {
  it('should create a task instance', () => {
    expect(new Task()).toBeTruthy();
  });
});
