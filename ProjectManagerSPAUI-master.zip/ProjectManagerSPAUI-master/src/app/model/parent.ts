export class Parent {
    id: number;
    task: string = '';
}
