export class User {
    id: number;
    firstName: string = '';
    lastName: string = '';
    employeeId: string = '';
    projectId: number;
    taskId: number;
}
