import { Parent } from './parent';

describe('Parent', () => {
  it('should create a Parent instance', () => {
    expect(new Parent()).toBeTruthy();
  });
});
