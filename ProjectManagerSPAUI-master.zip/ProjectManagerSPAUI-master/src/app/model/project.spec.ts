import { Project } from './project';

describe('Project', () => {
  it('should create a Project instance', () => {
    expect(new Project()).toBeTruthy();
  });
});
