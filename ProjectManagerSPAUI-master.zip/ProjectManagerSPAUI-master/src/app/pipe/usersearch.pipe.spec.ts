import { UsersearchPipe } from './usersearch.pipe';

describe('UsersearchPipe', () => {
  it('create an UsersearchPipe instance', () => {
    const pipe = new UsersearchPipe();
    expect(pipe).toBeTruthy();
  });
});
