import { ParentPipe } from './parent.pipe';

describe('ParentPipe', () => {
  it('create a ParentPipe instance', () => {
    const pipe = new ParentPipe();
    expect(pipe).toBeTruthy();
  });
});
