import { ProjectPipe } from './project.pipe';

describe('ProjectPipe', () => {
  it('create a ProjectPipe instance', () => {
    const pipe = new ProjectPipe();
    expect(pipe).toBeTruthy();
  });
});
