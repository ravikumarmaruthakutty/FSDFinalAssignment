import { FiltertaskPipe } from './filtertask.pipe';

describe('FiltertaskPipe', () => {
  it('create an FiltertaskPipe instance', () => {
    const pipe = new FiltertaskPipe();
    expect(pipe).toBeTruthy();
  });
});
