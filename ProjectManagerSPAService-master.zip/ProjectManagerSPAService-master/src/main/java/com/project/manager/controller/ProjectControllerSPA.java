package com.project.manager.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.manager.model.Project;
import com.project.manager.service.ProjectManagerServiceSPA;

@RestController
@RequestMapping("/projectservicespa/")
@CrossOrigin(origins = "*", maxAge = 3600)
public class ProjectControllerSPA {

	private static final Logger logger = LoggerFactory.getLogger(ProjectControllerSPA.class);
	
	@Autowired
	private ProjectManagerServiceSPA projectManagerServiceSPA;

	@GetMapping(value = "/projects", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<List<Project>> getAllProjects() {
		logger.info("ProjectControllerSPA :: getAllProjects");
		return new ResponseEntity<List<Project>>(this.projectManagerServiceSPA.getProjectList(), HttpStatus.OK);
	}

	@PostMapping(value = "/save", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<Project> saveOrUpdate(@RequestBody Project project) {
		logger.info("ProjectControllerSPA :: saveOrUpdate");
		return new ResponseEntity<Project>(this.projectManagerServiceSPA.saveOrUpdateProject(project), HttpStatus.OK);
	}
}
