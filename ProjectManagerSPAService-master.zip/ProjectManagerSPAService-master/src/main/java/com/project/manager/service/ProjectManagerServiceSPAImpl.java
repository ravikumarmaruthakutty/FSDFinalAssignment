package com.project.manager.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import com.project.manager.model.Parent;
import com.project.manager.model.Project;
import com.project.manager.model.Task;
import com.project.manager.model.User;
import com.project.manager.repository.ParentTaskRepositorySPA;
import com.project.manager.repository.ProjectRepositorySPA;
import com.project.manager.repository.TaskRepositorySPA;
import com.project.manager.repository.UserRepositorySPA;

@Service
public class ProjectManagerServiceSPAImpl implements ProjectManagerServiceSPA {

	@Autowired
	private TaskRepositorySPA taskRepositorySPA;

	@Autowired
	private ParentTaskRepositorySPA parentTaskRepositorySPA;

	@Autowired
	private ProjectRepositorySPA projectRepositorySPA;

	@Autowired
	private UserRepositorySPA userRepositorySPA;

	@Override
	public List<Task> getAllTasks() {
		List<Task> tasks = (List<Task>) this.taskRepositorySPA.findAll();
		tasks.forEach(task -> {
			if (task.getEndDate() != null) {
				task.setStatus((task.getEndDate().isBefore(LocalDateTime.now().toLocalDate())
						|| task.getEndDate().isEqual(LocalDateTime.now().toLocalDate())) ? "Completed" : "In-Progress");
			} else {
				task.setStatus("In-Progress");
			}
		});
		return tasks;
	}

	@Override
	public Task saveTask(Task task) {
		Task savedTask = this.taskRepositorySPA.save(task);
		User user = task.getUser();
		if (user != null && user.getFirstName() != null) {
			user.setTaskId(String.valueOf(task.getId()));
			this.userRepositorySPA.save(user);
		}
		return savedTask;
	}

	@Override
	public Task getTaskById(String id) {
		Optional<Task> opTask = this.taskRepositorySPA.findById(Integer.parseInt(id));
		if (!opTask.isPresent()) {
			throw new EmptyResultDataAccessException(1);
		}
		return opTask.get();
	}

	@Override
	public Task endTask(String taskId) {
		Task task = getTaskById(taskId);
		LocalDate currentDate = LocalDate.now();
		task.setEndDate(currentDate);
		Optional<Parent> parent = this.parentTaskRepositorySPA.findById(task.getId());
		if (parent.isPresent()) {
			parent.get().getTasks().forEach(t -> {
				t.setEndDate(currentDate);
				this.taskRepositorySPA.save(t);
			});
		}
		return this.taskRepositorySPA.save(task);
	}

	@Override
	public Project saveOrUpdateProject(Project project) {
		this.projectRepositorySPA.save(project);
		User user = project.getUser();
		user.setProjectId(String.valueOf(project.getProjectId()));
		this.userRepositorySPA.save(user);
		return project;
	}

	@Override
	public List<Project> getProjectList() {
		List<Project> projects = this.projectRepositorySPA.findAll();
		projects.forEach(p -> {
			List<User> users = this.getUserListByProjectId(p.getProjectId());
			if (users != null && !users.isEmpty()) {
				p.setUser(users.get(0));
			}
			p.setStatus((p.getEndDate().isBefore(LocalDateTime.now().toLocalDate())
					|| p.getEndDate().isEqual(LocalDateTime.now().toLocalDate())) ? "Completed" : "In-Progress");
		});
		return projects;
	}

	@Override
	public User saveOrUpdateUser(User user) {
		return this.userRepositorySPA.save(user);
	}

	@Override
	public List<User> getAllUsers() {
		return this.userRepositorySPA.findAll();
	}

	public List<User> getUserListByProjectId(Long projectId) {
		return this.userRepositorySPA.findOneUserByProjectId(String.valueOf(projectId));
	}

	@Override
	public List<Parent> getAllParent() {
		return (List<Parent>) this.parentTaskRepositorySPA.findAll();
	}

	@Override
	public Parent saveParentTask(Task task) {
		Parent parent = new Parent();
		parent.setTask(task.getTask());
		return this.parentTaskRepositorySPA.save(parent);
	}
}
