package com.project.manager.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.project.manager.model.Parent;
import com.project.manager.model.Project;
import com.project.manager.model.Task;
import com.project.manager.model.User;
import com.project.manager.repository.ParentTaskRepositorySPA;
import com.project.manager.repository.ProjectRepositorySPA;
import com.project.manager.repository.TaskRepositorySPA;
import com.project.manager.repository.UserRepositorySPA;

@RunWith(SpringRunner.class)
@ContextConfiguration
@TestPropertySource("/application-test.properties")
public class ProjectManagerServiceSPATests {

	@Autowired
	private Environment env;

	@TestConfiguration
	static class ProjectManagerServiceTestsContextConfiguration {

		@Bean
		public ProjectManagerServiceSPA projectManagerService() {
			return new ProjectManagerServiceSPAImpl();
		}
	}

	@Autowired
	private ProjectManagerServiceSPA projectManagerServiceSPA;
	
	@MockBean
	private TaskRepositorySPA taskRepositorySPA;
	
	@MockBean
	private ParentTaskRepositorySPA parentTaskRepositorySPA;
	
	@MockBean
	private ProjectRepositorySPA projectRepositorySPA;
	
	@MockBean
	private UserRepositorySPA userRepositorySPA;
	
	private Task task;
	private Parent parent;
	private User user;
	private Project project;

	@Before
	public void setUp() throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.registerModule(new JavaTimeModule());

		this.parent = mapper.readValue(this.env.getProperty("parent.json"), Parent.class);
		this.user = mapper.readValue(this.env.getProperty("user.json"), User.class);
		this.project = mapper.readValue(this.env.getProperty("project.json"), Project.class);
		this.task = mapper.readValue(this.env.getProperty("task.json"), Task.class);

		List<Task> tasks = new ArrayList<Task>();
		List<Parent> parents = new ArrayList<Parent>();
		List<Project> projects = new ArrayList<Project>();
		List<User> users = new ArrayList<User>();
		
		tasks.add(this.task);
		parents.add(this.parent);
		projects.add(this.project);
		users.add(this.user);
		this.parent.setTasks(tasks);

		Mockito.when(this.taskRepositorySPA.findAll()).thenReturn(tasks);
		Mockito.when(this.taskRepositorySPA.save(this.task)).thenReturn(this.task);
		Mockito.when(this.taskRepositorySPA.findById(Mockito.anyInt())).thenReturn(Optional.of(this.task));

		Mockito.when(this.parentTaskRepositorySPA.findAll()).thenReturn(parents);
		Mockito.when(this.parentTaskRepositorySPA.findById(Mockito.anyInt())).thenReturn(Optional.of(this.parent));

		Mockito.when(this.projectRepositorySPA.findAll()).thenReturn(projects);
		Mockito.when(this.userRepositorySPA.findOneUserByProjectId(Mockito.anyString())).thenReturn(users);
		Mockito.when(this.userRepositorySPA.findAll()).thenReturn(users);
	}

	@Test
	public void testGetAllTasks() {
		List<Task> tasks = this.projectManagerServiceSPA.getAllTasks();
		boolean[] pass = { false };
		tasks.forEach(task -> {
			if (task.getTask().equalsIgnoreCase(this.task.getTask())) {
				pass[0] = true;
			}
		});
		assertTrue(pass[0]);
	}

	@Test
	public void testGetAllParent() {
		List<Parent> parents = this.projectManagerServiceSPA.getAllParent();
		boolean[] pass = { false };
		parents.forEach(parent -> {
			if (parent.getTask().equalsIgnoreCase(this.parent.getTask())) {
				pass[0] = true;
			}
		});

	}

	@Test
	public void testGetTaskById() {
		Task task = this.projectManagerServiceSPA.saveTask(this.task);
		Task taskFound = this.projectManagerServiceSPA.getTaskById(String.valueOf(task.getId()));
		assertThat(taskFound.getTask().equalsIgnoreCase(this.task.getTask()));
	}

	@Test
	public void testSaveTask() {
		Task task = this.projectManagerServiceSPA.saveTask(this.task);
		assertThat(task.getTask().equalsIgnoreCase(this.task.getTask()));
	}

	@Test
	public void testEndTask() {
		Task task = this.projectManagerServiceSPA.saveTask(this.task);
		Task taskEnded = this.projectManagerServiceSPA.endTask(String.valueOf(task.getId()));
		LocalDate currentDate = LocalDate.now();
		assertThat(currentDate.compareTo(taskEnded.getEndDate()) == 0);
	}

	@Test
	public void testEndTask_Scenario1() {
		Task task = this.projectManagerServiceSPA.saveTask(this.task);
		Task taskEnded = this.projectManagerServiceSPA.endTask(String.valueOf(task.getId()));
		LocalDate currentDate = LocalDate.now();
		assertThat(currentDate.compareTo(taskEnded.getEndDate()) == 0);
	}

	@Test(expected = Test.None.class)
	public void testSaveParentTask() {
		this.projectManagerServiceSPA.saveParentTask(this.task);
	}

	@Test(expected = Test.None.class)
	public void testSaveOrUpdateUser() {
		this.projectManagerServiceSPA.saveOrUpdateUser(this.user);
	}

	@Test(expected = Test.None.class)
	public void testSaveOrUpdateProject() {
		this.projectManagerServiceSPA.saveOrUpdateProject(this.project);
	}

	@Test
	public void testGetProjectList() {
		List<Project> projects = this.projectManagerServiceSPA.getProjectList();
		boolean[] pass = { false };
		projects.forEach(parent -> {
			if (parent.getName().equalsIgnoreCase(this.project.getName())) {
				pass[0] = true;
			}
		});
		assertThat(pass[0] == true);
	}

	@Test
	public void testGetAllUsers() {
		List<User> users = this.projectManagerServiceSPA.getAllUsers();
		boolean[] pass = { false };
		users.forEach(user -> {
			if (user.getEmployeeId().equalsIgnoreCase(this.user.getEmployeeId())) {
				pass[0] = true;
			}
		});
		assertThat(pass[0] == true);
	}
}
